<?php
/**
 * Crowdsignal legacy plugin
 *
 * @package crowdsignal
 */

// silence is overrated.
